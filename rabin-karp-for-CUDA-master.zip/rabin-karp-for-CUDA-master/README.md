# rabin-karp-for-CUDA
Rabin Karp for CUDA
This program is a toy example of Rabin-Karp string matching implementation for CUDA.
Program successfully finds the positions of the pattern on the example string.
Variable num_cores denotes the number of threads to run the code on.
